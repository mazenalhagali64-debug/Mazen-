package com.mazen.phoneagent

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Gemini {
    /** Blocking call: run on Dispatchers.IO. Returns the model's text (JSON string). */
    fun ask(key: String, model: String, system: String, prompt: String, imgB64: String?): String {
        val parts = JSONArray().put(JSONObject().put("text", prompt))
        if (imgB64 != null) {
            parts.put(JSONObject().put("inline_data",
                JSONObject().put("mime_type", "image/jpeg").put("data", imgB64)))
        }
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", JSONObject()
                .put("responseMimeType", "application/json")
                .put("temperature", 0.2))
            .toString()

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        var lastErr = ""
        for (attempt in 1..3) {
            val c = url.openConnection() as HttpURLConnection
            try {
                c.requestMethod = "POST"
                c.connectTimeout = 20000
                c.readTimeout = 60000
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("x-goog-api-key", key)
                c.outputStream.use { it.write(body.toByteArray()) }
                val code = c.responseCode
                val text = (if (code in 200..299) c.inputStream else c.errorStream)
                    ?.bufferedReader()?.readText() ?: ""
                if (code in 200..299) {
                    val cand = JSONObject(text).getJSONArray("candidates").getJSONObject(0)
                    val ps = cand.getJSONObject("content").getJSONArray("parts")
                    val sb = StringBuilder()
                    for (i in 0 until ps.length()) sb.append(ps.getJSONObject(i).optString("text"))
                    return sb.toString()
                }
                lastErr = "HTTP $code: ${text.take(200)}"
                if (code != 429 && code != 503 && code != 500) break
            } catch (e: Exception) {
                lastErr = e.message ?: "network error"
            } finally {
                c.disconnect()
            }
            Thread.sleep(4000L * attempt)
        }
        throw RuntimeException(lastErr)
    }
}
