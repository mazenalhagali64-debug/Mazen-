package com.mazen.phoneagent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Bundle
import android.util.Base64
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.Toast
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume

class AgentService : AccessibilityService() {

    companion object {
        @Volatile var instance: AgentService? = null
        val logs = StringBuilder()
        var onLog: ((String) -> Unit)? = null

        private const val MAX_STEPS = 30

        private const val SYSTEM = """You control an Android phone to complete the user's task, acting like a careful human.
Each turn you receive: the task, the history of your previous actions with their results, a UI tree of the visible elements, and a screenshot.
UI tree line format: [id] Type "text" {flags} @x,y   (x,y = element center in real pixels).
Reply with ONE JSON object only: {"thought":"short reasoning","action":"...", ...params}
Actions:
- {"action":"tap","id":N}                      tap element N from the UI tree (preferred)
- {"action":"tap_xy","x":0-1000,"y":0-1000}   only if no tree element matches; coordinates normalized to the screenshot (0-1000)
- {"action":"type","id":N,"text":"..."}        replace the text of input element N (id optional = focused field)
- {"action":"enter"}                           press Enter/Search on the focused field (if it does nothing, tap an ENTER/Search key)
- {"action":"swipe","direction":"up|down|left|right"}   finger direction; to see content further down, swipe up
- {"action":"back"} {"action":"home"} {"action":"wait"}
- {"action":"open_app","name":"app name as shown on the home screen"}
- {"action":"done","message":"final result for the user, in Arabic"}
- {"action":"fail","message":"why it cannot be done, in Arabic"}
Rules: prefer tapping by id. After every action, check the new screen to verify it worked. If screen_changed is false, do NOT repeat the same action; try another way. Close popups and ads. Wait if the screen is still loading. Never enter passwords, make payments or delete data unless the task explicitly says so. When the task is finished, return done with the real result you saw on screen."""
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null
    private var stopButton: Button? = null
    private val nodes = mutableListOf<AccessibilityNodeInfo>()

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean { instance = null; job?.cancel(); return super.onUnbind(intent) }

    private fun log(s: String) { logs.append(s).append("\n"); onLog?.invoke(logs.toString()) }

    // ---------- entry point ----------
    fun start(task: String, key: String, model: String) {
        job?.cancel()
        logs.clear()
        job = scope.launch {
            showStop()
            try {
                log("▶ المهمة: $task")
                runLoop(task, key, model)
            } catch (e: CancellationException) {
                log("⏹ تم الإيقاف")
            } catch (e: Exception) {
                log("❌ خطأ: ${e.message}")
            } finally {
                hideStop()
            }
        }
    }

    private suspend fun runLoop(task: String, key: String, model: String) {
        performGlobalAction(GLOBAL_ACTION_HOME)
        val history = mutableListOf<String>()
        var lastHash = 0
        for (step in 1..MAX_STEPS) {
            delay(1300)
            val tree = readScreen()
            val shot = screenshotB64()
            val h = tree.hashCode()
            val changed = h != lastHash
            lastHash = h
            val m = resources.displayMetrics
            val prompt = buildString {
                append("TASK: $task\n")
                append("SCREEN: ${m.widthPixels}x${m.heightPixels}, screen_changed: $changed, step $step/$MAX_STEPS\n")
                append("HISTORY:\n${history.takeLast(8).joinToString("\n").ifBlank { "(none)" }}\n")
                append("UI TREE:\n$tree")
                if (shot == null) append("\n(no screenshot available)")
            }
            val raw = withContext(Dispatchers.IO) { Gemini.ask(key, model, SYSTEM, prompt, shot) }
            val a = try {
                JSONObject(raw.trim().removePrefix("```json").removeSuffix("```").trim())
            } catch (e: Exception) {
                history.add("step $step: invalid JSON reply, retry"); continue
            }
            val action = a.optString("action")
            log("• $step: ${a.optString("thought").take(100)} → $action")
            if (action == "done") { finish("✅ " + a.optString("message")); return }
            if (action == "fail") { finish("⚠ " + a.optString("message")); return }
            val result = exec(a)
            history.add("step $step: ${a.toString().take(150)} => $result")
        }
        finish("⚠ وصلت للحد الأقصى من الخطوات ($MAX_STEPS) بدون إنهاء المهمة")
    }

    private fun finish(msg: String) {
        log(msg)
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    // ---------- actions ----------
    private suspend fun exec(a: JSONObject): String = when (a.optString("action")) {
        "tap" -> tapNode(a.optInt("id", -1))
        "tap_xy" -> {
            val m = resources.displayMetrics
            tapXY((a.optDouble("x") / 1000 * m.widthPixels).toFloat(), (a.optDouble("y") / 1000 * m.heightPixels).toFloat())
        }
        "type" -> typeText(a.optInt("id", -1), a.optString("text"))
        "enter" -> pressEnter()
        "swipe" -> swipe(a.optString("direction"))
        "back" -> { performGlobalAction(GLOBAL_ACTION_BACK); "back" }
        "home" -> { performGlobalAction(GLOBAL_ACTION_HOME); "home" }
        "wait" -> { delay(2500); "waited" }
        "open_app" -> openApp(a.optString("name"))
        else -> "unknown action"
    }

    private suspend fun tapNode(i: Int): String {
        val n = nodes.getOrNull(i) ?: return "invalid element id"
        var c: AccessibilityNodeInfo? = n
        while (c != null && !c.isClickable) c = c.parent
        if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "clicked"
        val r = Rect(); n.getBoundsInScreen(r)
        return tapXY(r.centerX().toFloat(), r.centerY().toFloat())
    }

    private suspend fun tapXY(x: Float, y: Float): String {
        val p = Path().apply { moveTo(x, y) }
        return if (gesture(p, 60)) "tapped at ${x.toInt()},${y.toInt()}" else "tap gesture failed"
    }

    private fun typeText(i: Int, text: String): String {
        val n = nodes.getOrNull(i) ?: findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return "no input field found"
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        return if (n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) "typed" else "type failed"
    }

    private fun pressEnter(): String {
        val n = findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return "no focused field"
        return if (n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)) "enter sent" else "enter failed, tap the ENTER key instead"
    }

    private suspend fun swipe(dir: String): String {
        val m = resources.displayMetrics
        val w = m.widthPixels.toFloat(); val h = m.heightPixels.toFloat()
        val p = Path()
        when (dir) {
            "up" -> { p.moveTo(w / 2, h * 0.75f); p.lineTo(w / 2, h * 0.25f) }
            "down" -> { p.moveTo(w / 2, h * 0.25f); p.lineTo(w / 2, h * 0.75f) }
            "left" -> { p.moveTo(w * 0.8f, h / 2); p.lineTo(w * 0.2f, h / 2) }
            "right" -> { p.moveTo(w * 0.2f, h / 2); p.lineTo(w * 0.8f, h / 2) }
            else -> return "bad direction"
        }
        return if (gesture(p, 350)) "swiped $dir" else "swipe failed"
    }

    private fun openApp(name: String): String {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val app = pm.queryIntentActivities(intent, 0)
            .firstOrNull { it.loadLabel(pm).toString().contains(name, ignoreCase = true) }
            ?: return "app '$name' not found"
        val launch = pm.getLaunchIntentForPackage(app.activityInfo.packageName) ?: return "cannot launch"
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launch)
        return "opened ${app.loadLabel(pm)}"
    }

    private suspend fun gesture(p: Path, dur: Long): Boolean = suspendCancellableCoroutine { c ->
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build()
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { if (c.isActive) c.resume(true) }
            override fun onCancelled(d: GestureDescription?) { if (c.isActive) c.resume(false) }
        }, null)
        if (!ok && c.isActive) c.resume(false)
    }

    // ---------- reading the screen ----------
    private fun readScreen(): String {
        nodes.clear()
        val root = rootInActiveWindow ?: return "(empty or protected screen)"
        val sb = StringBuilder()
        walk(root, sb)
        return sb.toString().ifBlank { "(no readable elements, rely on the screenshot)" }
    }

    private fun walk(n: AccessibilityNodeInfo, sb: StringBuilder) {
        if (nodes.size >= 150) return
        if (n.isVisibleToUser) {
            val text = (n.text ?: n.contentDescription ?: "").toString().replace("\n", " ").take(80)
            if (n.isClickable || n.isEditable || n.isScrollable || n.isCheckable || text.isNotBlank()) {
                val r = Rect(); n.getBoundsInScreen(r)
                val kind = n.className?.toString()?.substringAfterLast('.') ?: "View"
                val flags = buildList {
                    if (n.isClickable) add("click"); if (n.isEditable) add("edit")
                    if (n.isScrollable) add("scroll"); if (n.isChecked) add("checked")
                }.joinToString(",")
                sb.append("[${nodes.size}] $kind \"$text\" {$flags} @${r.centerX()},${r.centerY()}\n")
                nodes.add(n)
            }
        }
        for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it, sb) }
    }

    /** The service itself takes the screenshot: no manual capture needed. */
    private suspend fun screenshotB64(): String? = suspendCancellableCoroutine { c ->
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val out = try {
                    val hw = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)!!
                    val bmp = hw.copy(Bitmap.Config.ARGB_8888, false)
                    hw.recycle(); r.hardwareBuffer.close()
                    val w = 720; val h = bmp.height * w / bmp.width
                    val sc = Bitmap.createScaledBitmap(bmp, w, h, true)
                    val o = ByteArrayOutputStream(); sc.compress(Bitmap.CompressFormat.JPEG, 70, o)
                    Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
                } catch (e: Exception) { null }
                if (c.isActive) c.resume(out)
            }
            override fun onFailure(code: Int) { if (c.isActive) c.resume(null) }
        })
    }

    // ---------- floating stop button ----------
    private fun showStop() {
        if (stopButton != null) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val b = Button(this).apply { text = "⏹ إيقاف"; setOnClickListener { job?.cancel() } }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; y = 160 }
        wm.addView(b, lp); stopButton = b
    }

    private fun hideStop() {
        stopButton?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
        stopButton = null
    }
}
