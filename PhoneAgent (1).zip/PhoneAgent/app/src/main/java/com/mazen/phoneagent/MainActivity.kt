package com.mazen.phoneagent

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var logView: TextView

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun edit(hint: String, v: String) = EditText(this).apply { setHint(hint); setText(v) }

        val key = edit("مفتاح Gemini API", prefs.getString("key", "") ?: "")
        key.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        val model = edit("اسم الموديل", prefs.getString("model", "gemini-flash-latest") ?: "gemini-flash-latest")
        val task = edit("اكتب المهمة، مثلاً: افتح Termux ونفّذ ping google.com وقلّي النتيجة", "")
        task.minLines = 3

        val btnAcc = Button(this).apply {
            text = "1) فعّل خدمة الوصول"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val btnGo = Button(this).apply {
            text = "2) ابدأ التنفيذ"
            setOnClickListener {
                val svc = AgentService.instance
                if (svc == null) { Toast.makeText(context, "فعّل خدمة الوصول أولاً", Toast.LENGTH_LONG).show(); return@setOnClickListener }
                if (key.text.isBlank() || task.text.isBlank()) { Toast.makeText(context, "أدخل المفتاح والمهمة", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                prefs.edit().putString("key", key.text.toString().trim()).putString("model", model.text.toString().trim()).apply()
                svc.start(task.text.toString(), key.text.toString().trim(), model.text.toString().trim())
            }
        }
        logView = TextView(this).apply { textSize = 14f }
        val scroll = ScrollView(this).apply { addView(logView) }

        listOf(key, model, task, btnAcc, btnGo, scroll).forEach { root.addView(it) }
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        logView.text = AgentService.logs.toString()
        AgentService.onLog = { t -> logView.text = t }
    }

    override fun onPause() { super.onPause(); AgentService.onLog = null }
}
